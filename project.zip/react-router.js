export {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from 'react-router-dom';
